<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exported Data</title>
</head>
<body>
    <h1>Exported Data</h1>

    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Exam Name</th>
                <th>KKM</th>
                <th>Benar</th>
                <th>Salah</th>
                <th>Nilai</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($attempt->user->name); ?></td>
                    <td><?php echo e($attempt->exam->exam_name); ?></td>
                    <td><?php echo e($attempt->exam->pass_marks); ?></td>
                    <td class="total-correct-answers" data-attempt-id="<?php echo e($attempt->id); ?>">
                        <?php echo e($attempt->benar); ?> 
                    </td>
                    <td class="total-incorrect-answers" data-attempt-id="<?php echo e($attempt->id); ?>">
                        <?php echo e($attempt->salah); ?> 
                    </td>
                    <td class="total-score" data-attempt-id="<?php echo e($attempt->id); ?>">
                        <?php echo e($attempt->nilai); ?> 
                    </td>
                    <td>
                        <?php if($attempt->status == 0): ?>
                            <span style="color:red">Tidak Lulus</span>
                        <?php else: ?>
                            <span style="color: green">Lulus</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views//admin/export.blade.php ENDPATH**/ ?>