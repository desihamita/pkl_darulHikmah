<?php $__env->startSection('title', 'Siswa/I'); ?>
<?php $__env->startSection('titleContent', 'Siwa/I'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline">
            <div class="card-header">
              <h3 class="card-title mt-2">
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-create">
                    Tambah Data
                  </button>
                  <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal-import">
                    Import Data
                </button>
              </h3>

              <div class="card-tools">
                  <div class="input-group mt-2" >
                    <form action="<?php echo e(route('studentDashboard')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control float-right" placeholder="Search" value="<?php echo e($request->get('search')); ?>">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                  </div>
                </div>
            </div>
            <div class="card-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama</th>
                        <th>kelas</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($students) > 0): ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($student->nis); ?></td>
                                <td><?php echo e($student->name); ?></td>
                                <td>
                                    <?php if($student->kelas): ?>
                                        <?php echo e($student->kelas->class); ?>

                                    <?php else: ?>
                                        No Class Assigned
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($student->email); ?></td>
                                <td>
                                    <button class="btn btn-info updateButton" data-id="<?php echo e($student->id); ?>" data-student="<?php echo e($student->name); ?>" data-email="<?php echo e($student->email); ?>" data-nis="<?php echo e($student->nis); ?>" data-kelas="<?php echo e($student->kelas_id); ?>" data-toggle="modal" data-target="#modal-update">Update</button>

                                    <button class="btn btn-danger deleteButton" data-id="<?php echo e($student->id); ?>" data-student="<?php echo e($student->name); ?>" data-kelas="<?php echo e($student->kelas_id); ?>" data-toggle="modal" data-target="#modal-delete">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">Siswa/I Tidak Ditemukan!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama</th>
                        <th>kelas</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-create">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Tambah Data</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form id="createStudent">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label for="NIS">NIS</label>
                    <input type="text" class="form-control" name="nis" placeholder="Enter Student NIS" required>
                </div>
                <div class="form-group">
                    <label for="Nama">Nama</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Student Name" required>
                </div>
                <div class="form-group">
                    <label for="kelas">Kelas</label>
                    <select name="kelas_id" class="form-control" required>
                        <option value="">Select Kelas</option>
                        <?php if(count($kelas) > 0): ?>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->class); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="Email">Email</label>
                    <input type="text" class="form-control" name="email" placeholder="Enter Student Email" required>
                </div>
                <div class="form-group">
                    <label for="Password">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter Student Password" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-update">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Ubah Data Siswa/i</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form id="updateStudent">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <label for="NIS">NIS</label>
                            <input type="text" name="nis" id="nis"  placeholder="Enter Exam NIS" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="Nama">Nama</label>
                            <input type="text" name="nama" id="nama" placeholder="Enter Exam Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="kelas">Kelas</label>
                            <select name="kelas_id" id="kelas_id" class="form-control" required>
                                <option value="">Select Kelas</option>
                                <?php if(count($kelas) > 0): ?>
                                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->class); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="Enter Your Email" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus Data Siswa/I</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form id="deleteStudent">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p>Are you sure you want to delete Siswa/i?</p>
                        <input type="hidden" name="id" id="delete_student_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-import">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Import Data Siswa/I</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form id="importStudent" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="file" name="file" id="fileupload" required accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.openxmlformats-officedocument.wordprocessingml.document" class="form-control">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning">Import Qna</button>
                </div>
            </form>
          </div>
        </div>
    </div>

</section>
<script>
    $(document).ready(function () {
        $('#createStudent').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('createStudent')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // Update subject
        $('.updateButton').click(function() {
            var id = $(this).attr('data-id');
            var nis = $(this).attr('data-nis');
            var name = $(this).attr('data-student');
            var email = $(this).attr('data-email');
            var kelas_id = $(this).attr('data-kelas');

            $("#nis").val(nis);
            $("#nama").val(name);
            $("#email").val(email);
            $("#kelas_id").val(kelas_id);
            $("#id").val(id);
        });

        $('#updateStudent').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('updateStudent')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // delete Qna
        $('.deleteButton').click(function() {
            var id = $(this).attr('data-id');
            $('#delete_student_id').val(id)
        });

        $('#deleteStudent').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('deleteStudent')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // import Qna
        $('#importStudent').submit(function (e) {
            e.preventDefault();
            let formData = new FormData();
            formData.append("file", fileupload.files[0]);
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN":"<?php echo e(csrf_token()); ?>",
                }
            });

            $.ajax({
                url: "<?php echo e(route('importStudent')); ?>",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/admin/student-dashboard.blade.php ENDPATH**/ ?>