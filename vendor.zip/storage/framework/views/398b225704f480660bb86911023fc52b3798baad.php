<!DOCTYPE html>
<html>
<head>
    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td, #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
        h1 {
            text-align: center;
            font-weight: bold;
        }

        dl {
            font-size: 14px;
            margin: 0;
            padding-bottom: 20px;
        }

        dt, dd {
            display: inline-block;
            margin: 0;
        }

        dt {
            font-weight: bold;
        }

        dt::after {
            content: ":";
        }

        dd {
            margin-left: 5px;
        }
    </style>
</head>
<body>

    <h1>Hasil Ujian</h1>

    <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <dl>
            <dt>Nama</dt>
            <dd><?php echo e($attempt['user_name']); ?></dd><br>

            <dt>Kelas</dt>
            <dd><?php echo e($attempt['kelas']); ?></dd><br>

            <dt>Semester</dt>
            <dd><?php echo e($attempt['semester']); ?></dd><br>

            <dt>Nama Ujian</dt>
            <dd><?php echo e($attempt['exam_name']); ?></dd>
        </dl>

        <table id="customers">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Mata Pelajaran</th>
                    <th>KKM</th>
                    <th>Benar</th>
                    <th>Salah</th>
                    <th>Nilai</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($attempt['mapel']); ?></td>
                    <td><?php echo e($attempt['pass_marks']); ?></td>
                    <td class="total-correct-answers" data-attempt-id="<?php echo e($attempt['id']); ?>"><?php echo e($attempt['correct']); ?></td>
                    <td class="total-incorrect-answers" data-attempt-id="<?php echo e($attempt['id']); ?>"><?php echo e($attempt['incorrect']); ?></td>
                    <td class="total-score" data-attempt-id="<?php echo e($attempt['id']); ?>"><?php echo e($attempt['score']); ?></td>
                    <td><?php echo e($attempt['status']); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>
<?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/admin/export.blade.php ENDPATH**/ ?>