<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="text-center">
            <h2>Thanks for submit your exam, <?php echo e(Auth::user()->name); ?></h2>
            <p>We will review your exam</p>
            <a href="/dashboard" class="btn btn-info">Go back</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/thank-you.blade.php ENDPATH**/ ?>