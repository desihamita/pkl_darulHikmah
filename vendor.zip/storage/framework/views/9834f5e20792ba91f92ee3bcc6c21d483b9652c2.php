<?php $__env->startSection('title', 'Mata Pelajaran'); ?>
<?php $__env->startSection('titleContent', 'Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline">
            <div class="card-header">
              <h3 class="card-title mt-2">
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-create">
                      Tambah Data
                  </button>
              </h3>

              <div class="card-tools">
                  <div class="input-group mt-2" >
                    <form action="<?php echo e(route('subjectDashboard')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control float-right" placeholder="Search" value="<?php echo e($request->get('search')); ?>">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                  </div>
                </div>
            </div>
            <div class="card-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($subjects) > 0): ?>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->subject); ?></td>
                                <td>
                                    <button class="btn btn-info updateButton" data-id="<?php echo e($item->id); ?>" data-subject="<?php echo e($item->subject); ?>" data-toggle="modal" data-target="#modal-update">Update</button>

                                    <button class="btn btn-danger deleteButton" data-id="<?php echo e($item->id); ?>" data-subject="<?php echo e($item->subject); ?>" data-toggle="modal" data-target="#modal-delete">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">Mata Pelajaran Tidak Ditemukan!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-create">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Tambah Data Mata Pelajaran</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" id="createSubject">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <label for="">Mata Pelajaran</label>
                    <input type="text" name="subject" placeholder="Enter Nama Mata Pelajaran" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-update">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Ubah Data Mata Pelajaran</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form id="updateSubject">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label for="">Mata Pelajaran</label>
                        <input type="text" name="subject" placeholder="Enter Subject Name" id="update_subject" required class="form-control">
                        <input type="hidden" name="id" id="update_subject_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus Data Mata Pelajaran</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form id="deleteSubject">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p>Are you sure you want to delete subject?</p>
                        <input type="hidden" name="id" id="delete_subject_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>

</section>
<script>
    $(document).ready(function () {
        $('#createSubject').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('createSubject')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // Update subject
        $('.updateButton').click(function() {
            var subject_id = $(this).attr('data-id');
            var subject = $(this).attr('data-subject');

            $("#update_subject").val(subject);
            $("#update_subject_id").val(subject_id);
        });

        $('#updateSubject').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('updateSubject')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // Delete Subject
        $(".deleteButton").click(function (){
            var subject_id = $(this).attr('data-id');
            $("#delete_subject_id").val(subject_id);
        });

        $('#deleteSubject').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('deleteSubject')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/admin/subject-dashboard.blade.php ENDPATH**/ ?>