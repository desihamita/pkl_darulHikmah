<?php $__env->startSection('title', 'Ujian'); ?>
<?php $__env->startSection('titleContent', 'Ujian'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline">
            <div class="card-header">
              <h3 class="card-title mt-2">
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-create">
                    Tambah Data
                  </button>
              </h3>

              <div class="card-tools">
                  <div class="input-group mt-2" >
                    <form action="<?php echo e(route('examDashboard')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control float-right" placeholder="Search" value="<?php echo e($request->get('search')); ?>">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                  </div>
                </div>
            </div>
            <div class="card-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Token</th>
                        <th>Nama Ujian</th>
                        <th>Mata Pelajaran</th>
                        <th>Kelas</th>
                        <th>Tanggal Ujian</th>
                        <th>Waktu Ujian</th>
                        <th>KKM</th>
                        <th>Tambah Pertanyaan</th>
                        <th>Lihat Pertanyaan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($exams) > 0): ?>
                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($exam->token); ?></td>
                                <td><?php echo e($exam->exam_name); ?></td>
                                <td><?php echo e($exam->subjects->subject); ?></td>
                                <td>
                                    <?php if($exam->kelas): ?>
                                        <?php echo e($exam->kelas->class); ?>

                                    <?php else: ?>
                                        No Class Assigned
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($exam->date); ?></td>
                                <td><?php echo e($exam->time); ?> hrs</td>
                                <td><?php echo e($exam->pass_marks); ?> </td>
                                <td>
                                    <a href="" class="addQuestion" data-id="<?php echo e($exam->id); ?>" data-toggle="modal" data-target="#addQnaModal">Add Question</a>
                                </td>
                                <td>
                                    <a href="" class="seeQuestion" data-id="<?php echo e($exam->id); ?>" data-toggle="modal" data-target="#seeQnaModal">See Question</a>
                                </td>
                                <td id="statusBadge_<?php echo e($exam->id); ?>">
                                    <?php if($exam->status == true): ?>
                                        <span class="badge badge-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Tidak Aktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-warning updateStatusButton" data-id="<?php echo e($exam->id); ?>" data-exam="<?php echo e($exam->exam_name); ?>" data-status="<?php echo e($exam->status); ?>" >Ubah Status</button>

                                    <button class="btn btn-info updateButton" data-id="<?php echo e($exam->id); ?>" data-exam="<?php echo e($exam->exam_name); ?>" data-toggle="modal" data-target="#modal-update">Update</button>

                                    <button class="btn btn-danger deleteButton" data-id="<?php echo e($exam->id); ?>" data-exam="<?php echo e($exam->exam_name); ?>" data-toggle="modal" data-target="#modal-delete">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">Ujian Tidak Ditemukan!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Token</th>
                        <th>Nama Ujian</th>
                        <th>Mata Pelajaran</th>
                        <th>Kelas</th>
                        <th>Tanggal Ujian</th>
                        <th>Waktu Ujian</th>
                        <th>Percobaan</th>
                        <th>Tambah Pertanyaan</th>
                        <th>Lihat Pertanyaan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-create">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Tambah Data</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <form id="createExam">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="exam_name">Nama Ujian</label>
                        <input type="text" name="exam_name" placeholder="Enter Exam Name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="mata_pelajaran">Mata Pelajaran</label>
                        <select name="subject_id" class="form-control" required>
                            <option value="">Select Subject</option>
                            <?php if(count($subjects) > 0): ?>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="kelas">Kelas</label>
                        <select name="kelas_id" class="form-control" required>
                            <option value="">Select Kelas</option>
                            <?php if(count($kelas) > 0): ?>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->class); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="date">Tanggal Ujian</label>
                        <input type="date" name="date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="time">Waktu Ujian</label>
                        <input type="time" name="time" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="pass_marks">KKM</label>
                        <input type="text" name="pass_marks" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
      </div>
    </div>

    
    <div class="modal fade" id="modal-update">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Ubah Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form id="updateExam">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="exam_id" id="exam_id">
                    <div class="form-group">
                        <label for="exam_name">Nama Ujian</label>
                        <input type="text" name="exam_name" id="exam_name" placeholder="Enter Exam Name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="subject">Mata Pelajaran</label>
                        <select name="subject_id" id="exam_subject_id" class="form-control" required>
                            <option value="">Select Subject</option>
                            <?php if(count($subjects) > 0): ?>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="kelas">Kelas</label>
                        <select name="kelas_id" id="exam_kelas_id" class="form-control" required>
                            <option value="">Select Kelas</option>
                            <?php if(count($kelas) > 0): ?>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->class); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="date">Tanggal Ujian</label>
                        <input type="date" name="date" class="form-control" min="<?php echo date('Y-m-d'); ?>" id="exam_date" required>
                    </div>
                    <div class="form-group">
                        <label for="time">Waktu Ujian</label>
                        <input type="time" name="time" class="form-control" id="exam_time" required>
                    </div>
                    <div class="form-group">
                        <label for="pass_marks">KKM</label>
                        <input type="text" name="pass_marks" class="form-control" id="exam_pass_marks" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
          </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form id="deleteExam">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <p>Are you sure you want to delete exam?</p>
                    <input type="hidden" name="exam_id" id="delete_exam_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
          </div>
        </div>
    </div>

    
    <div class="modal fade" id="addQnaModal" >
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pertanyaan dan Jawaban</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="addQna">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="exam_id" id="addExamId">

                        <div class="row mb-3">
                            <div class="col-md-3">
                                <label for="">Filter by kelas</label>
                                <select name="filter_kelas_id" id="filter_kelas_id" class="form-control filter-select" required>
                                    <option value="">Select Kelas</option>
                                    <?php if(count($kelas) > 0): ?>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->class); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="">Filter by Mata Pelajaran</label>
                                <select name="filter_subject_id" id="filter_subject_id" class="form-control filter-select" required>
                                    <option value="">Select Subject</option>
                                    <?php if(count($subjects) > 0): ?>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <table class="table table-bordered table-striped" id="example2 questionsTable">
                            <thead>
                                <th>Pilih</th>
                                <th>Kelas</th>
                                <th>Mata Pelajaran</th>
                                <th>Pertanyaan</th>
                            </thead>
                            <tbody class="addBody">

                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create question Modal -->
    <div class="modal fade" id="seeQnaModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Soal Ujian</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <div class="modal-body">
                        <table class="table">
                            <thead>
                                <th>No</th>
                                <th>Soal</th>
                                <th>Delete</th>
                            </thead>
                            <tbody class="seeQuestionTable">

                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function () {
        $('#createExam').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('createExam')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // Update subject
        $(document).on('click', '.updateButton', function() {
            var id = $(this).attr('data-id');
            $("#exam_id").val(id);

            var url = '<?php echo e(route("getExamDetail", "id")); ?>';
            url = url.replace('id', id);

            $.ajax({
                url: url,
                type: "GET",
                success: function(data) {
                    if (data.success == true) {
                        var exam = data.data;
                        $("#exam_name").val(exam[0].exam_name);
                        $("#exam_subject_id").val(exam[0].subject_id);
                        $("#exam_kelas_id").val(exam[0].kelas_id);
                        $("#exam_time").val(exam[0].time);
                        $("#exam_date").val(exam[0].date);
                        $("#exam_pass_marks").val(exam[0].pass_marks);
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });
        $('#updateExam').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('updateExam')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // Delete Subject
        $(document).on('click', '.deleteButton', function() {
            var id = $(this).attr('data-id');
            $("#delete_exam_id").val(id);
        });
        $('#deleteExam').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('deleteExam')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        // add Questions
        $(document).on('click', '.addQuestion', function() {
            var id = $(this).attr('data-id');
            $('#addExamId').val(id);

            $.ajax({
                url: "<?php echo e(route('getQuestions')); ?>",
                type: "GET",
                data: {exam_id: id},
                success: function(data) {
                    if (data.success == true) {
                        var questions = data.data;
                        var html = '';
                        if (questions.length > 0) {
                            for (let i = 0; i < questions.length; i++) {
                                html += `
                                    <tr>
                                        <td>
                                            <input type="checkbox" value="${questions[i]['id']}" name="questions_ids[]">
                                        </td>
                                        <td>
                                            ${questions[i]['kelas']}
                                        </td>
                                        <td>
                                            ${questions[i]['subject_name']}
                                        </td>
                                        <td>
                                            ${questions[i]['questions']}
                                        </td>
                                    </tr>
                                `;
                            }
                        } else {
                            html += `
                                <tr>
                                    <td colspan='2'>Questions not available</td>
                                </tr>
                            `;
                        }
                        $('.addBody').html(html);
                    } else {
                        alert(data.msg);
                    }
                }
            })
        });
        $('#addQna').submit(function (e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('addQuestions')); ?>",
                type: "POST",
                data: formData,
                success: function (data) {
                    if (data.success == true) {
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });

        //filter data kelas dan subject
        function updateTable(classId, subjectId) {
            $.ajax({
                url: "<?php echo e(route('getQuestions')); ?>",
                type: "GET",
                data: {
                    exam_id: $('#addExamId').val(),
                    kelas_id: classId,
                    subject_id: subjectId
                },
                success: function (data) {
                    var questions = data.data;
                    var html = '';

                    if (questions.length > 0) {
                        for (let i = 0; i < questions.length; i++) {
                            html += `
                                <tr>
                                    <td>
                                        <input type="checkbox" value="${questions[i]['id']}" name="questions_ids[]">
                                    </td>
                                    <td>${questions[i]['kelas']}</td>
                                    <td>${questions[i]['subject_name']}</td>
                                    <td>${questions[i]['questions']}</td>
                                </tr>
                            `;
                        }
                    } else {
                        html += `
                            <tr>
                                <td colspan="4">No questions available for the selected class and subject</td>
                            </tr>
                        `;
                    }

                    $('.addBody').html(html);
                },
                error: function (xhr, textStatus, errorThrown) {
                    console.error("Error fetching questions:", errorThrown);
                },
            });
        }
        $('#filter_kelas_id, #filter_subject_id').change(function () {
            var classId = $('#filter_kelas_id').val();
            var subjectId = $('#filter_subject_id').val();
            updateTable(classId, subjectId);
        });
        $('#addQnaModal').on('show.bs.modal', function () {
            var classId = $('#filter_kelas_id').val();
            var subjectId = $('#filter_subject_id').val();
            updateTable(classId, subjectId);
        });

        // see Questions
        $(document).on('click', '.seeQuestion', function() {
            var id = $(this).attr('data-id');

            $.ajax({
                url: "<?php echo e(route('getExamQuestions')); ?>",
                type: "GET",
                data: {exam_id: id},
                success:function(data) {
                    var questions = data.data;
                    var html = '';
                    if (questions.length > 0) {
                        for(let i=0; i<questions.length; i++){
                            if (questions[i]['question'] !== null && questions[i]['question'] !== undefined) {
                                html +=`
                                    <tr>
                                        <td>`+(i+1)+`</td>
                                        <td>`+questions[i]['question']['question']+`</td>
                                        <td>
                                            <button class="btn btn-danger deleteQuestion" data-id="`+questions[i]['id']+`">Delete</button>
                                        </td>
                                    </tr>
                                `;
                            } else {
                                console.error('Question data is null or undefined for index:', i);
                            }

                        }
                    } else {
                        html +=`
                            <tr>
                                <td colspan='2'>Questions not available</td>
                            </tr>
                        `;
                    }
                    $('.seeQuestionTable').html(html);
                }
            })
        });

        // delete Question
        $(document).on('click', '.deleteQuestion', function(){
            var id = $(this).attr('data-id');
            var obj = $(this);
            $.ajax({
                url: "<?php echo e(route('deleteExamQuestions')); ?>",
                type: "GET",
                data: {id: id},
                success:function(data) {
                    if (data.success == true) {
                        obj.parent().parent().remove();
                    } else {
                        alert(data.msg);
                    }
                }
            })
        });

        // update status
        $(document).on('click', '.updateStatusButton', function() {
            var id = $(this).attr('data-id');

            $.ajax({
                url: "<?php echo e(url('update-status')); ?>/" + id,
                type: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                },
                success: function(data) {
                    if (data.status == true) {
                        $('#statusBadge_' + id).html('<span class="badge badge-success">Aktif</span>');
                        location.reload();
                    } else if(data.status == false) {
                        $('#statusBadge_' + id).html('<span class="badge badge-danger">Tidak Aktif</span>');
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/admin/exam-dashboard.blade.php ENDPATH**/ ?>