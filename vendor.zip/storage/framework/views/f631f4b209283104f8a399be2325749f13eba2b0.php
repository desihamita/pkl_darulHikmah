<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="content-header"></div>
        <div class="container">
            <div class="row">
                <?php
                    $activeExams = $exams->where('status', true);
                    $userClassId = Auth::user()->kelas->class;
                    $foundActiveExams = false;
                ?>

                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->status == true && $item->kelas->class == $userClassId): ?>
                        <div class="col-lg-5">
                            <div class="card card-primary card-outline">
                                <div class="card-header">
                                    <h5 class="card-title m-0"><?php echo e($item->exam_name); ?></h5>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="<?php echo e(route('check.token')); ?>" >
                                        <?php echo csrf_field(); ?>
                                        <dl class="row">
                                            <dt class="col-sm-4">Mata Pelajaran</dt>
                                            <dd class="col-sm-8">: <?php echo e($item->subjects->subject); ?></dd>

                                            <dt class="col-sm-4">Kelas</dt>
                                            <dd class="col-sm-8">: <?php echo e($item->kelas->class); ?> / Semester <?php echo e($item->kelas->semester); ?></dd>

                                            <dt class="col-sm-4">Tanggal Ujian</dt>
                                            <dd class="col-sm-8">: <?php echo e($item->date); ?></dd>

                                            <dt class="col-sm-4">Waktu Ujian</dt>
                                            <dd class="col-sm-8">: <?php echo e($item->time); ?></dd>

                                            <dt class="col-sm-4">Jumlah Soal</dt>
                                            <dd class="col-sm-8">: <?php echo e($item->qnaExams->count()); ?></dd>

                                            <dt class="col-sm-4">Token</dt>
                                            <dd class="col-sm-8"><input type="text" name="token" id="token" class="form-control"></dd>
                                        </dl>
                                        <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                                            <button class="btn btn-primary" type="submit">Mulai</button>
                                        </div>
                                    </form>
                                    <div id="notif">
                                        <?php if(session('message')): ?>
                                            <?php echo e(session('message')); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            $foundActiveExams = true;
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!$foundActiveExams): ?>
                    <div class="col-lg-12">
                        <div class="alert alert-info" role="alert">
                            Tidak ada ujian yang aktif saat ini.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\files\Semester 7\proyek darul hikmah\PKl-DarulHikmah\resources\views/student/dashboard.blade.php ENDPATH**/ ?>